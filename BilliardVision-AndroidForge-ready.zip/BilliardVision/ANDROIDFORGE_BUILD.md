# Billiard Vision — AndroidForge Build

این ZIP برای Build آنلاین پروژه Android با AndroidForge آماده شده است.

## تنظیمات پیشنهادی

- Build variant: `debug`
- Project type: Gradle / Kotlin (تشخیص خودکار)
- خروجی مورد انتظار: `app-debug.apk`

## نکته

این پروژه Gradle Wrapper ندارد. AndroidForge طبق مستندات خودش می‌تواند
برای پروژه‌های بدون/ناقص بودن Wrapper از Gradle مناسب استفاده یا Wrapper را
بازسازی کند.

## بعد از Build

در پایان Workflow، از بخش Artifacts فایل APK را دانلود کن.
