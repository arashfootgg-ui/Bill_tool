package com.example.billiardvision

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PointF
import android.media.Image
import java.nio.ByteBuffer
import kotlin.math.sqrt

data class AnalysisResult(
    val balls: List<PointF>,
    val cueBall: PointF?
)

object FrameAnalyzer {

    /*
     * نسخه MVP:
     * - فریم RGBA را به Bitmap تبدیل می‌کند.
     * - نواحی بسیار روشن را به‌عنوان کاندید توپ بررسی می‌کند.
     *
     * این الگوریتم عمداً ساده است تا pipeline زنده تست شود.
     * مرحله بعد: تشخیص هندسی میز + Hough circles + طبقه‌بندی رنگ توپ‌ها.
     */
    fun analyze(image: Image): AnalysisResult {
        val plane = image.planes[0]
        val buffer: ByteBuffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)

        val scaled = Bitmap.createScaledBitmap(bitmap, 360, 640, true)
        val candidates = mutableListOf<PointF>()

        // نمونه‌ی سبک: جست‌وجوی پیکسل‌های روشن در تصویر کوچک‌شده.
        // برای جلوگیری از هزینه زیاد، شبکه‌ای نمونه‌برداری می‌شود.
        val step = 8
        for (y in 0 until scaled.height step step) {
            for (x in 0 until scaled.width step step) {
                val c = scaled.getPixel(x, y)
                val r = (c shr 16) and 0xff
                val g = (c shr 8) and 0xff
                val b = c and 0xff

                if (r > 205 && g > 205 && b > 205) {
                    candidates.add(
                        PointF(
                            x.toFloat() / scaled.width,
                            y.toFloat() / scaled.height
                        )
                    )
                }
            }
        }

        bitmap.recycle()
        scaled.recycle()

        // فعلاً یک نمونه محدود نگه می‌داریم تا Overlay شلوغ نشود.
        val balls = candidates.take(20)
        val cue = balls.firstOrNull()

        return AnalysisResult(balls, cue)
    }
}
