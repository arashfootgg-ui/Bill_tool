package com.example.billiardvision

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.min

class OverlayView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var result = AnalysisResult(emptyList(), null)

    fun setAnalysis(newResult: AnalysisResult, width: Int, height: Int) {
        result = newResult
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5f

        val w = width.toFloat()
        val h = height.toFloat()

        // کادر آزمایشی میز؛ در نسخه بعد از تصویر تشخیص داده می‌شود.
        val left = w * 0.05f
        val right = w * 0.95f
        val top = h * 0.20f
        val bottom = h * 0.80f

        paint.color = Color.argb(120, 0, 255, 0)
        canvas.drawRect(left, top, right, bottom, paint)

        // نمایش کاندیدهای توپ.
        paint.style = Paint.Style.STROKE
        paint.color = Color.YELLOW
        result.balls.forEach { p ->
            val x = p.x * w
            val y = p.y * h
            canvas.drawCircle(x, y, min(w, h) * 0.012f, paint)
        }

        // خط آزمایشی از توپ سفید به جهت فرضی.
        result.cueBall?.let { cue ->
            val x = cue.x * w
            val y = cue.y * h

            paint.color = Color.RED
            paint.strokeWidth = 8f
            canvas.drawLine(
                x,
                y,
                min(right, x + w * 0.30f),
                y,
                paint
            )
        }
    }
}
